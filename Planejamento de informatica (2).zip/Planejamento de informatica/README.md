# PROJETO PRÁTICO EM SISTEMAS


## Integrantes
- Adriano Miranda Batista          RA 2223104272
- Matheus Rosa Fernandes de Souza  RA 2223105314
- Rogério Rosa Fernandes           RA 2223105443
- Yuri Alves Mourão                RA 2223103805

  ### DESCRIÇÃO

  - Nosso projeto trata-se de uma de Projeto de extensão universitária, trabalhamos em uma criação e desenvolvimento web site, referenciando um site e-commerce.

    Link de produção:
    - Vs code Studio
      - html
      - CSS
      - Javascript
   
  ### LINK DO YOUTUBE:
https://youtu.be/IiDwys6kFPc
